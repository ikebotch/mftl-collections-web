export const settlementsValidatorPlaceholder = true
