export const dashboardValidatorPlaceholder = true
