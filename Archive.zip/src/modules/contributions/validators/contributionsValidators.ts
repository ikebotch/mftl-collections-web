export const contributionsValidatorPlaceholder = true
