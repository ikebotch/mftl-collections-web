export const reportsValidatorPlaceholder = true
