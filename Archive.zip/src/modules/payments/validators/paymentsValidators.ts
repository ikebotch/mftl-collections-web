export const paymentsValidatorPlaceholder = true
