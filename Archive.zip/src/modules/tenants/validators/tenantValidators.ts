export const tenantValidatorPlaceholder = true
