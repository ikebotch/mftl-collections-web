export const receiptsValidatorPlaceholder = true
