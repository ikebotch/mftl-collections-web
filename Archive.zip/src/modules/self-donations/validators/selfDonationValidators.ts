export const selfDonationValidatorPlaceholder = true
